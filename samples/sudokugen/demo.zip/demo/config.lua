application = 
{
	content = 
	{ 
		width = 768*2,
		height = 1024*2,
		scale = "letterbox",		
	}
}
