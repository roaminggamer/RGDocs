--------------------------------------------------------------------------------
-- Copyright (c) 2016 Roaming Gamer, LLC.
--
-- MIT Licensed
-- 
-- Permission is hereby granted, free of charge, to any person obtaining a copy 
-- of this software and associated documentation files (the "Software"), to deal 
-- in the Software without restriction, including without limitation the rights 
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
-- copies of the Software, and to permit persons to whom the Software is furnished 
-- to do so, subject to the following conditions:
--  
-- The above copyright notice and this permission notice shall be included in all 
-- copies or substantial portions of the Software. 
--  
-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,  
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL  
-- THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER  
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,  
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE  
-- SOFTWARE.
--------------------------------------------------------------------------------

local sudokugen = require "plugin.sudokugen"

local size = 140

local demo = {}

local function showGrid( grid, boxes, startX, startY )	

	local x = startX + size 
	local y = startY + 2 * size
	for i = 1, boxes do
		local box = display.newRect( x, y, size * 3, size * 3 )
		if( i%2 == 1 ) then
			box:setFillColor( 1,1,1 )
		else
			box:setFillColor( 0,0,0.5 )
		end
		x = x + size * 3
		if( i%3 == 0) then
			x = startX + size
			y = y + size * 3
		end
	end

	local x = startX
	local y = startY + size
	for i = 1, #grid do
		local rect = display.newRect( x, y, size-30, size-30 )
		rect:setFillColor( 0, 0.25, 0.25 )
		x = x + size
		if( i%9 == 0) then
			x = startX
			y = y + size
		end
		rect.label = display.newText( grid[i], rect.x, rect.y, native.systemFont, 26 )
	end
end


function demo.run()
	print(system.getTimer())
	local sample = sudokugen.gen_sudoku3( math.random(1,1000) )
	showGrid( sample, 9, size, size/2 )
	print(system.getTimer())

end



return demo
