--------------------------------------------------------------------------------
-- Copyright (c) 2016 Roaming Gamer, LLC.
--
-- MIT Licensed
-- 
-- Permission is hereby granted, free of charge, to any person obtaining a copy 
-- of this software and associated documentation files (the "Software"), to deal 
-- in the Software without restriction, including without limitation the rights 
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
-- copies of the Software, and to permit persons to whom the Software is furnished 
-- to do so, subject to the following conditions:
--  
-- The above copyright notice and this permission notice shall be included in all 
-- copies or substantial portions of the Software. 
--  
-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,  
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL  
-- THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER  
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,  
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE  
-- SOFTWARE.
--------------------------------------------------------------------------------

local sudokugen = require "plugin.sudokugen"

local function dump2by2( puzzle ) 
	local toPrint = ""
	for i = 1, #puzzle do
		toPrint = toPrint .. string.format("%x", tonumber(puzzle[i]))
		if( i == 2 or i == 6 or i == 10 or i == 14 ) then
			toPrint = toPrint .. "|"
		end
		if( i == 4 or i == 8 or i == 12 or i == 16) then
			if( i == 12  ) then
				print( "-----")
			end
			print(toPrint)
			toPrint = ""
		end
	end
	print("\n")
end

local grid = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
local layout = sudokugen.gen_sudoku2( 0, grid )
dump2by2( layout )


local puzzle1 = sudokugen.gen_sudoku2( 1 )
local puzzle2 = sudokugen.gen_sudoku2( 2 )

-- Clone upper left box from last puzzle
local grid = {}
for i = 1, 16 do
	grid[i] = 0
end
grid[1] = puzzle2[11]
grid[2] = puzzle2[12]
grid[5] = puzzle2[15]
grid[6] = puzzle2[16]

local puzzle3 = sudokugen.gen_sudoku2( 2, grid )

dump2by2( puzzle1 )
dump2by2( puzzle2 )
dump2by2( puzzle3 )

